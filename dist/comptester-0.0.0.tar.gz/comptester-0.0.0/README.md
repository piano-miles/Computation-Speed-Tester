# Computation-Speed-Tester
A simple program to test the computation speed of different ways to get the same answer.

## Dependencies
Uses random, time, matplotlib, and tqdm. To install dependencies, run `python3 -m pip install matplotlib tqdm` in the commandline.
